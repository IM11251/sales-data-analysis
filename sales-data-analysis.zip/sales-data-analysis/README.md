# Sales Data Analysis (Excel)

This project demonstrates basic data analysis and visualization using Excel.

## 📊 Project Description
The dataset simulates sales data for a fictional retail company. The Excel workbook includes:

- Monthly sales by product category
- Pivot tables for region-based analysis
- Charts to visualize trends and performance
- Conditional formatting to highlight key values

## 🛠 Tools Used
- Microsoft Excel
- Power BI (optional extension)
- Basic data cleaning & charting

## 🧠 Skills Demonstrated
- Excel: Pivot tables, formulas, formatting, visualization
- Analytical thinking
- Business reporting

---

Feel free to explore, customize, and extend this project for your own portfolio.
